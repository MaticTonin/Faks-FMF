import matplotlib.pyplot as plt
import numpy as np 
import scipy.optimize as sp

#data location
import os
THIS_FOLDER = os.path.dirname(os.path.abspath(__file__))
my_file = os.path.join(THIS_FOLDER, "laser_podatki.txt") 

#data load and manipulation
x, y = np.loadtxt(my_file, delimiter="\t", unpack="True")
x_0=1584019423.2113843
sumI_0=0
x=x-x_0
for y in range(len(y)):
    sumI_0+=y
    
avrg=sumI_0/len(y)
print("Povprečje toka je: %.2E  mA", avrg*10**(3))
#fitting function
f = lambda x, a, b : a*x + b
args = [20, 0]
fit = sp.curve_fit(f, x, y, p0=args)

fitlabel = "$%.2E \\frac{N}{A} * I + %.2E$"%(fit[0][0], fit[0][1])
print(fitlabel)
t0 = np.linspace(-3.551, 3.553, 1000)


#plotting
#plt.ylim(-1e-4, 1e-3)
plt.scatter(x, y, color="black", marker=".")
#plt.errorbar(x, y, label='meritve', barsabove="True", linestyle="None", color="black", capsize=5)
plt.plot(t0, f(t0, fit[0][0], fit[0][1]), label=fitlabel)

plt.xlabel("I[A]")
plt.ylabel("F[N]")
plt.legend()
plt.title("F(I)")
#plt.savefig("Sila v odvisnosti toka.png")
plt.show()
